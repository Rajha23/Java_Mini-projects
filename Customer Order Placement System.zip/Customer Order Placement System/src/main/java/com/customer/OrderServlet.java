package com.customer;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {

    private Connection conn;

    // Initialize DB connection
    @Override
    public void init() throws ServletException {
        String url = "jdbc:mysql://localhost:3306/customer_orders";
        String user = "root";       // change if needed
        String password = "root";   // change to your DB password

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Database connected successfully!");
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException("DB Connection problem: " + e.getMessage());
        }
    }

    // Handle GET requests: redirect to form
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("order.html"); // redirect user to the HTML form
    }

    // Handle POST requests: process order
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Read parameters
        String name = request.getParameter("name");
        String item = request.getParameter("item");
        String quantityStr = request.getParameter("quantity");

        // Debug print
        System.out.println("DEBUG - Received Name: '" + name + "', Item: '" + item + "', Quantity: '" + quantityStr + "'");

        // Trim and validate inputs
        name = (name != null) ? name.trim() : "";
        item = (item != null) ? item.trim() : "";
        quantityStr = (quantityStr != null) ? quantityStr.trim() : "";

        if (name.isEmpty()) {
            out.println("<h3 style='color:red;'>Error: Name is required!</h3>");
            return;
        }
        if (item.isEmpty()) {
            out.println("<h3 style='color:red;'>Error: Item is required!</h3>");
            return;
        }
        if (quantityStr.isEmpty()) {
            out.println("<h3 style='color:red;'>Error: Quantity is required!</h3>");
            return;
        }

        int quantity = 0;
        try {
            quantity = Integer.parseInt(quantityStr);
            if (quantity <= 0) {
                out.println("<h3 style='color:red;'>Error: Quantity must be a positive number!</h3>");
                return;
            }
        } catch (NumberFormatException e) {
            out.println("<h3 style='color:red;'>Error: Quantity must be a valid number!</h3>");
            return;
        }

        // Insert into database
        try {
            String sql = "INSERT INTO orders (customer_name, item, quantity) VALUES (?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, item);
            pst.setInt(3, quantity);

            int rows = pst.executeUpdate();
            if (rows > 0) {
                out.println("<h2 style='color:green;'>Order Placed Successfully!</h2>");
                out.println("<p><b>Name:</b> " + name + "</p>");
                out.println("<p><b>Item:</b> " + item + "</p>");
                out.println("<p><b>Quantity:</b> " + quantity + "</p>");
            } else {
                out.println("<h3 style='color:red;'>Failed to place order.</h3>");
            }
        } catch (SQLException e) {
            out.println("<h3 style='color:red;'>Database Error: " + e.getMessage() + "</h3>");
        }
    }

    // Close DB connection
    @Override
    public void destroy() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Database connection closed!");
            }
        } catch (SQLException e) {
            System.out.println("Error closing DB: " + e.getMessage());
        }
    }
}
